/*
Phonograph 1.0.1 (http://github.com/sebastianjacobs/phonograph)
Built by Sebastian Jacobs (http://sebastianjacobs.com)
Licensed under the MIT license
*/
music.controller('musicController', function($scope, $rootScope, $location, musicControl) {
  $scope.titles = [
    {
      title: 'New Divide',
      artist: 'Linkin Park',
      album: 'New Divide',
      genre: 'Rock',
      cover: 'new-divide.jpg',
      titleLength: '4:28',
      file: 'example.mp3'
    },
    {
      title: 'She Moves',
      artist: 'Alle Farben',
      album: 'Far Away',
      genre: 'Electro',
      cover: 'far-away.jpg',
      titleLength: '3:03',
      file: 'example.mp3'
    },
    {
      title: 'Heathens',
      artist: 'twenty one pilots',
      album: 'Suicide Squad',
      genre: 'Rap',
      cover: 'suicide-squad.jpg',
      titleLength: '3:15',
      file: 'example.mp3'
    },
    {
      title: 'No Good',
      artist: 'Kaleo',
      album: 'A/B',
      genre: 'Rock',
      cover: 'a-b.jpg',
      titleLength: '3:54',
      file: 'example.mp3'
    },
    {
      title: 'Way Down We Go',
      artist: 'Kaleo',
      album: 'A/B',
      genre: 'Rock',
      cover: 'a-b.jpg',
      titleLength: '3:39',
      file: 'example.mp3'
    }
  ];
  $scope.musicFlags = musicControl.flags;
  $scope.playMusic = musicControl.playMusic;
  $scope.pauseMusic = musicControl.pauseMusic;
  $scope.stopMusic = musicControl.stopMusic;
  $scope.muteMusic = musicControl.muteMusic;
  $scope.unmuteMusic = musicControl.unmuteMusic;
  $scope.playListMusic = function(titleName, artistName, fileName) {
    $rootScope.titleName = titleName;
    $rootScope.artistName = artistName;
    $rootScope.fileName = fileName;
    musicControl.playListMusic(titleName, artistName, fileName);
  }
  $scope.location = $location.path();
  $rootScope.$on('$routeChangeSuccess', function() {
    $scope.location = $location.path();
  });
});
