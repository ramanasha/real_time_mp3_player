# Phonograph 1.0.1

A music web player built with Angular and Bootstrap.

[DEMO](https://sebastianjacobs.github.io/phonograph/) (without music files)

![preview](/images/preview.gif?raw=true "Preview")

## Getting Started

###### Add music in 3 steps:

1. Upload your music files into the folder "files".
2. Upload the cover images of your albums into "images/covers".
3. Add the songs to musicController (js/controllers/musicController).

###### Code example for musicController:

```
{
    title: 'New Divide',
    artist: 'Linkin Park',
    album: 'New Divide',
    genre: 'Rock',
    cover: 'example.png',
    titleLength: '4:28',
    file: 'example.mp3'
}
```
Add this into the array $scope.titles to add new songs to Phonograph.

That's it!  :+1:
